// IWXA domain.json validator (config_schema_version 1.0.0)
// Generated from src/config/validateDomainConfig.ts by scripts/build-validator.mjs.
// Do not edit by hand.

// src/config/validateDomainConfig.ts
var ALLOWED_TOP_LEVEL = [
  "config_schema_version",
  "config_version",
  "status",
  "domain_id",
  "origin",
  "local_store_name",
  "workspace_profile",
  "brand",
  "runtime",
  "modules",
  "enabled_profiles",
  "enabled_capabilities",
  "handoff",
  "service_worker",
  "diagnostics",
  "security",
  "release"
];
var SECRET_KEY_RE = /(secret|password|passwd|token|api[_-]?key|private[_-]?key|bearer|credential|access[_-]?key)/i;
var SECRET_KEY_ALLOWLIST = /* @__PURE__ */ new Set(["allow_secrets"]);
var SERVICE_ID_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
var BASE_PATH_RE = /^\/[A-Za-z0-9._\-/]*$/;
var DOMAIN_ID_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
function isPlainObject(v) {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
function err(code, message, details) {
  return { ok: false, code, message, details };
}
function normOrigin(o) {
  try {
    const u = new URL(o);
    return u.protocol + "//" + u.host;
  } catch {
    return o;
  }
}
function assertNoSecretsDeep(value, path) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      assertNoSecretsDeep(value[i], path.concat(String(i)));
    }
    return;
  }
  for (const k of Object.keys(value)) {
    if (!SECRET_KEY_ALLOWLIST.has(k) && SECRET_KEY_RE.test(k)) {
      const p = path.concat(k).join(".");
      const e = new Error('secret-like key: "' + p + '"');
      e.path = p;
      throw e;
    }
    assertNoSecretsDeep(value[k], path.concat(k));
  }
}
function validateDomainConfig(raw, opts = {}) {
  try {
    assertNoSecretsDeep(raw, []);
  } catch (e) {
    return err(
      "SECRET_FIELD_FORBIDDEN",
      "domain.json must not contain secret-like keys",
      { path: e.path }
    );
  }
  if (!isPlainObject(raw)) {
    return err("CONFIG_INVALID", "domain.json must be a JSON object");
  }
  const o = raw;
  if (typeof o.config_schema_version !== "string") {
    return err("CONFIG_INVALID", 'config_schema_version must be "1.0.0"');
  }
  if (o.config_schema_version !== "1.0.0") {
    return err(
      "UPDATE_REQUIRED",
      'Unsupported config_schema_version: "' + o.config_schema_version + '"',
      { got: o.config_schema_version, expected: "1.0.0" }
    );
  }
  for (const k of Object.keys(o)) {
    if (ALLOWED_TOP_LEVEL.indexOf(k) < 0) {
      return err("CONFIG_INVALID", 'Unknown top-level field: "' + k + '"');
    }
  }
  for (const k of ALLOWED_TOP_LEVEL) {
    if (!(k in o)) {
      return err("CONFIG_INVALID", 'Missing required field: "' + k + '"');
    }
  }
  if (typeof o.config_version !== "string" || !o.config_version) {
    return err("CONFIG_INVALID", "config_version must be a non-empty string");
  }
  if (typeof o.status !== "string" || !o.status) {
    return err("CONFIG_INVALID", "status must be a non-empty string");
  }
  if (typeof o.domain_id !== "string" || !DOMAIN_ID_RE.test(o.domain_id)) {
    return err("CONFIG_INVALID", "domain_id must be url-safe");
  }
  if (typeof o.workspace_profile !== "string" || !o.workspace_profile) {
    return err("CONFIG_INVALID", "workspace_profile must be a non-empty string");
  }
  if (o.local_store_name !== "iwxa-local") {
    return err("CONFIG_INVALID", 'local_store_name must be exactly "iwxa-local"');
  }
  if (!isPlainObject(o.service_worker) || o.service_worker.mode !== "disabled") {
    return err(
      "CONFIG_INVALID",
      'service_worker.mode must be "disabled" (architecture lock)'
    );
  }
  if (typeof o.service_worker.future_path !== "string") {
    return err("CONFIG_INVALID", "service_worker.future_path must be a string");
  }
  if (typeof o.service_worker.future_scope !== "string") {
    return err("CONFIG_INVALID", "service_worker.future_scope must be a string");
  }
  if (typeof o.origin !== "string" || !/^https?:\/\//.test(o.origin)) {
    return err("CONFIG_INVALID", "origin must be an http(s) URL");
  }
  if (typeof o.brand !== "string" && !isPlainObject(o.brand)) {
    return err("CONFIG_INVALID", "brand must be a string or an object");
  }
  if (!isPlainObject(o.runtime)) {
    return err("CONFIG_INVALID", "runtime must be an object");
  }
  if (!Array.isArray(o.modules)) {
    return err("CONFIG_INVALID", "modules must be an array");
  }
  const seenModuleIds = /* @__PURE__ */ new Set();
  for (let i = 0; i < o.modules.length; i++) {
    const m = o.modules[i];
    if (!isPlainObject(m)) return err("CONFIG_INVALID", "modules[" + i + "] must be an object");
    if (typeof m.service_id !== "string" || !SERVICE_ID_RE.test(m.service_id)) {
      return err("CONFIG_INVALID", "modules[" + i + "].service_id must be url-safe");
    }
    if (typeof m.base_path !== "string" || !BASE_PATH_RE.test(m.base_path)) {
      return err("CONFIG_INVALID", "modules[" + i + '].base_path must start with "/"');
    }
    if (seenModuleIds.has(m.service_id)) {
      return err("CONFIG_INVALID", "modules[" + i + "].service_id is duplicated");
    }
    seenModuleIds.add(m.service_id);
  }
  if (!Array.isArray(o.enabled_profiles)) {
    return err("CONFIG_INVALID", "enabled_profiles must be an array");
  }
  for (let i = 0; i < o.enabled_profiles.length; i++) {
    if (typeof o.enabled_profiles[i] !== "string" || !o.enabled_profiles[i]) {
      return err("CONFIG_INVALID", "enabled_profiles[" + i + "] must be non-empty string");
    }
  }
  if (!Array.isArray(o.enabled_capabilities)) {
    return err("CONFIG_INVALID", "enabled_capabilities must be an array");
  }
  for (const c of o.enabled_capabilities) {
    if (c !== "T0" && c !== "T1" && c !== "T2") {
      return err(
        "CONFIG_INVALID",
        "enabled_capabilities entries must be one of T0, T1, T2 (got: " + JSON.stringify(c) + ")"
      );
    }
  }
  const h = o.handoff;
  if (!isPlainObject(h)) return err("CONFIG_INVALID", "handoff must be an object");
  if (typeof h.enabled !== "boolean") return err("CONFIG_INVALID", "handoff.enabled must be boolean");
  if (typeof h.receive_path !== "string" || !h.receive_path) {
    return err("CONFIG_INVALID", "handoff.receive_path must be a non-empty string");
  }
  if (!Array.isArray(h.allowed_origins)) {
    return err("CONFIG_INVALID", "handoff.allowed_origins must be an array");
  }
  if (typeof h.require_preview !== "boolean") {
    return err("CONFIG_INVALID", "handoff.require_preview must be boolean");
  }
  if (typeof h.default_expiry_seconds !== "number" || h.default_expiry_seconds < 0) {
    return err("CONFIG_INVALID", "handoff.default_expiry_seconds must be a non-negative number");
  }
  if (!isPlainObject(o.diagnostics) || typeof o.diagnostics.enabled !== "boolean") {
    return err("CONFIG_INVALID", "diagnostics.enabled must be boolean");
  }
  if (!isPlainObject(o.security)) {
    return err("CONFIG_INVALID", "security must be an object");
  }
  if (!isPlainObject(o.release)) {
    return err("CONFIG_INVALID", "release must be an object");
  }
  if (!opts.dev) {
    const cur = opts.current_origin;
    if (typeof cur !== "string" || !cur) {
      return err("ORIGIN_MISMATCH", "current origin is unavailable");
    }
    if (normOrigin(cur) !== normOrigin(o.origin)) {
      return err(
        "ORIGIN_MISMATCH",
        'Origin mismatch: expected "' + o.origin + '", got "' + cur + '"',
        { expected: o.origin, actual: cur }
      );
    }
  }
  return { ok: true, config: o };
}
function acceptedOrigin(config) {
  return normOrigin(config.origin);
}
export {
  acceptedOrigin,
  validateDomainConfig
};
